document.addEventListener("DOMContentLoaded", () => {
  const userNameInput = document.getElementById("userNameInput");
  const saveUserNameButton = document.getElementById("saveUserName");
  const userDisplay = document.getElementById("userDisplay");
  const chatList = document.getElementById("chatList");

  chrome.storage.sync.get(["userName", "chats"], ({ userName, chats }) => {
      if (userName) {
          userDisplay.textContent = `Utente: ${userName}`;
          userNameInput.value = userName;

          if (chats) {
              chats.forEach(chat => {
                  const chatItem = document.createElement("li");
                  const chatLink = document.createElement("a");
                  chatLink.href = `https://chatgpt.com${chat.link}`;
                  chatLink.textContent = chat.title;
                  chatLink.target = "_blank";
                  chatItem.appendChild(chatLink);
                  chatList.appendChild(chatItem);
              });
          }
      }

      saveUserNameButton.addEventListener("click", () => {
          const userName = userNameInput.value.trim();
          if (userName) {
              chrome.storage.sync.set({ userName }, () => {
                  userDisplay.textContent = `Utente: ${userName}`;
                  alert("Nome utente salvato: " + userName);
              });
          } else {
              alert("Inserisci un nome utente valido.");
          }
      });
  });
});
