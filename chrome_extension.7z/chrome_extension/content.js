chrome.storage.sync.get(["userName", "chats"], ({ userName, chats }) => {
  if (userName) {
      const chatLinks = chats ? chats.map(chat => chat.link) : [];

      const hideUnstoredChats = () => {
          const chatElements = document.querySelectorAll('a[href^="/c/"]');

          chatElements.forEach(chatElement => {
              const chatLink = chatElement.getAttribute('href');
              const chatExists = chatLinks.includes(chatLink);

              if (!chatExists) {
                  chatElement.closest('li').style.display = 'none';
              }
          });
      };

      // Nascondi le chat non memorizzate al caricamento della pagina
      window.addEventListener('load', hideUnstoredChats);

      // Nascondi le chat non memorizzate subito dopo il caricamento del DOM
      document.addEventListener('DOMContentLoaded', hideUnstoredChats);

      const observer = new MutationObserver((mutations) => {
          mutations.forEach((mutation) => {
              mutation.addedNodes.forEach(node => {
                  if (node.nodeType === 1 && node.querySelector('a[href^="/c/"]')) {
                      const chatElement = node.querySelector('a[href^="/c/"]');
                      const chatLink = chatElement.getAttribute('href');

                      const checkChatTitle = () => {
                          const chatTitle = chatElement.textContent.trim();
                          if (chatTitle !== "New chat") {
                              const chatExists = chatLinks.includes(chatLink);

                              // Inizializza chats se undefined
                              if (!chats) {
                                  chats = [];
                              }

                              if (!chatExists) {
                                  chats.push({ title: chatTitle, link: chatLink });
                                  chrome.storage.sync.set({ chats }, () => {
                                      alert("Nuova chat salvata per " + userName + ": " + chatTitle);
                                      chatLinks.push(chatLink); // Aggiorna l'elenco dei link salvati
                                  });
                              }
                          } else {
                              setTimeout(checkChatTitle, 5000);
                          }
                      };

                      checkChatTitle();
                  }
              });
          });
      });

      observer.observe(document.body, {
          childList: true,
          subtree: true
      });
  } else {
      alert("Nome utente non trovato. Per favore, inseriscilo nel popup dell'estensione.");
  }
});
