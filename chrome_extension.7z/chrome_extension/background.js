chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get("userName", ({ userName }) => {
    if (!userName) {
      chrome.action.setPopup({ popup: "popup.html" });
      chrome.action.openPopup();
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "checkUser") {
    chrome.storage.sync.get("userName", ({ userName }) => {
      sendResponse({ userName });
    });
    return true;
  }
});
